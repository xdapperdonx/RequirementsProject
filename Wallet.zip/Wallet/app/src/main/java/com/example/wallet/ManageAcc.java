package com.example.wallet;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import com.google.android.material.button.MaterialButton;

public class ManageAcc extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_manage_acc);

        MaterialButton btnEscManageAcc = (MaterialButton) findViewById(R.id.btnEscManage);
        MaterialButton btnEditAcc = (MaterialButton) findViewById(R.id.btnEditAcc);
        MaterialButton btnChangeCard = (MaterialButton) findViewById(R.id.btnChangeCard); //prompt to change card
        MaterialButton btnLogout = (MaterialButton) findViewById(R.id.btnLogout);

        btnEscManageAcc.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(ManageAcc.this, MainPage.class);
                startActivity(intent);
            }
        });

        btnEditAcc.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(ManageAcc.this, EditAcc.class);
                startActivity(intent);
            }
        });

        /*
        btnChangeCard.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(ManageAcc.this, .class);
                startActivity(intent);
            }
        });
         */

        btnLogout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(ManageAcc.this, Login.class);
                startActivity(intent);
            }
        });
    }
}