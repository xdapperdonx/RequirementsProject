package com.example.wallet;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.material.button.MaterialButton;

public class CreateAccount extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create_account);

        MaterialButton btnCreateAcc = (MaterialButton) findViewById(R.id.btnCreateAccount2);
        MaterialButton btnEscCreate = (MaterialButton) findViewById(R.id.btnEscCreate);
        EditText txtCreateUser = (EditText) findViewById(R.id.createUser);
        EditText txtCreatePass = (EditText) findViewById(R.id.createPas);

        btnCreateAcc.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(!TextUtils.isEmpty(txtCreateUser.getText()) && !TextUtils.isEmpty(txtCreatePass.getText()))
                {
                    //add to database
                    Toast.makeText(CreateAccount.this, "User added to database!",Toast.LENGTH_SHORT).show();
                    Intent intent = new Intent(CreateAccount.this, MainPage.class);
                    startActivity(intent);
                }
            }
        });

        btnEscCreate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(CreateAccount.this, Login.class);
                startActivity(intent);
            }
        });
    }
}