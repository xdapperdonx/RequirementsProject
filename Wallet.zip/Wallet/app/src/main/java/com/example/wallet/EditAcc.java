package com.example.wallet;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

import com.google.android.material.button.MaterialButton;

public class EditAcc extends AppCompatActivity {

    private String newPass = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_acc);

        MaterialButton btnEscEdit = (MaterialButton) findViewById(R.id.btnEscEdit);
        MaterialButton btnChangeUsername = (MaterialButton) findViewById(R.id.btnChangeUsername);
        MaterialButton btnChangePassword = (MaterialButton) findViewById(R.id.btnChangePassword);
        MaterialButton btnApplyChanges = (MaterialButton) findViewById(R.id.btnApplyChanges);

        btnEscEdit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(EditAcc.this, ManageAcc.class);
                startActivity(intent);
            }
        });

        btnChangeUsername.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                AlertDialog.Builder myAlertBuilder = new AlertDialog.Builder(EditAcc.this);
                myAlertBuilder.setTitle("Enter your new Username: ");
                myAlertBuilder.setMessage("New Username");
                myAlertBuilder.setPositiveButton("Enter", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        Toast.makeText(EditAcc.this, "You clicked yes.", Toast.LENGTH_SHORT).show();
                    }
                });

                myAlertBuilder.setNegativeButton("Back", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        Toast.makeText(EditAcc.this, "You clicked no.", Toast.LENGTH_SHORT).show();
                    }
                });
                myAlertBuilder.show();
            }
        });


         btnChangePassword.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                AlertDialog.Builder myAlertBuilder = new AlertDialog.Builder(EditAcc.this);
                myAlertBuilder.setTitle("Enter new password: ");
                myAlertBuilder.setMessage("New Password");

                myAlertBuilder.setPositiveButton("Enter", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        Toast.makeText(EditAcc.this, "You clicked yes.", Toast.LENGTH_SHORT).show();
                    }
                });

                myAlertBuilder.setNegativeButton("Back", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        Toast.makeText(EditAcc.this, "You clicked no.", Toast.LENGTH_SHORT).show();
                    }
                });
                myAlertBuilder.show();
            }
        });

        btnApplyChanges.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(EditAcc.this, "Applied Changes!",Toast.LENGTH_SHORT).show();
                Intent intent = new Intent(EditAcc.this, ManageAcc.class);
                startActivity(intent);
            }
        });
    }
}